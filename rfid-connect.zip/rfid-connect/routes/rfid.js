var express = require('express');
var request = require('request');
//var http = require('http');
//var http = require('httpclient');

var router = express.Router();
//var url = 'http://impinj-14-04-4f/api/v1/';

router.post('/status', function (req, res, next) {
    //console.log(req.body.readerHostApiPath);
    request.get({
        uri: `${req.body.readerHostApiPath}status`
        // headers: {
        //     'Content-Type': 'application/json'
        // }
    }, function (error, response, body) {
        if (error) return console.log(error);
        //res.json(body);
    }).pipe(res, true);
});

router.post('/start', function (req, res, next) {
    request.post({
        uri: `${req.body.readerHostApiPath}profiles/inventory/presets/${req.body.presetName}/start`
    }, function (error, response, body) {
        if (error) return console.log(error);
    }).pipe(res, true);
});

router.post('/stop', function (req, res, next) {
    request.post({
        uri: `${req.body.readerHostApiPath}profiles/stop`
    }, function (error, response, body) {
        if (error) return console.log(error);
    }).pipe(res, true);
});

router.post('/search', function (req, res, next) {
    request.post({
        uri: `${req.body.readerHostApiPath}profiles/inventory/tag`,
        qs: {epc: req.body.epc, antennaPort: req.body.antennaPort}
    }, function (error, response, body) {
        if (error) return console.log(error);
    }).pipe(res, true);
});

router.post('/read', function (req, res, next) {
    request.get({
        uri: encodeURI(`${req.body.readerHostApiPath}data/stream`),
    }, function (error, response, body) {
        if (error) {
            console.log(error);
            //res.error = error;
            //res.end();
        }
    }).pipe(res, true); //.flushHeaders();

    // var request = http.get(`${req.body.readerHostApiPath}data/stream`, function (response) {
    //     //response.pipe(res);
    // }).pipe(res, true);

    // var request = http.get(`${req.body.readerHostApiPath}data/stream`, function (response) {
    //     var str = '';
    //     //console.log('Response is '+res.statusCode);

    //     response.on('data', function (chunk) {
    //         str += chunk;
    //         res.send(chunk);
    //     });

    //     response.on('end', function () {
    //         console.log(str);
    //         res.send(str);
    //         res.end();
    //     });

    //     response.on('error', function (error) {
    //         console.log(error);
    //     });
    // });
});

module.exports = router;